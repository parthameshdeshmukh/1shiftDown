"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const app = (0, express_1.default)();
const port = process.env.PORT || 5000;
app.use((0, cors_1.default)());
app.use(express_1.default.json({ limit: '50mb' }));
app.get('/', (req, res) => {
    res.send('1Shift Down API is running');
});
// Import routes
const routes_1 = __importDefault(require("./routes"));
app.use('/api', routes_1.default);
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
